## ALL WORKFORCE JOBS KPI UI ## -----
employment_workforce_all_kpi_card_ui <- function(id) {
  ns <- NS(id)
  tagList(
    uiOutput(ns("card"))
  )
}

## ALL WORKFORCE JOBS KPI SERVER ## -----
employment_workforce_all_kpi_card_server <- function(id) {
  moduleServer(id, function(input, output, session) {

    output$card <- build_kpi_card(
      id              = session$ns("workforce_all"),
      title           = "All Workforce Jobs (000s)",
      schema          = "ons",
      table           = "labour_market__workforce_jobs",
      filter_col      = "sic_section",
      filter_value    = "A-T",
      parse_mode      = "MMM YY (p)",
      good_if_increase = TRUE,
      format_headline = govuk_format_number,
      format_delta    = function(x) govuk_format_number_signed(x, digits = 0)
    )
  })
}
