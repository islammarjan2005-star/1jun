### WORKFORCE JOBS BY INDUSTRY BLOCK  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

## WORKFORCE JOBS UI ## -----
employment_workforce_industry_stats_card_ui <- function(id) {
  ns <- NS(id)
  tags$script("$(function() {$('[data-toggle=\"tooltip\"]').tooltip();});")

  tagList(

    # --- Industry breakdown card  ---
    mod_govuk_data_vis_card_ui(
      id = ns("workforce_industry_card"),
      title = "Workforce Jobs by Industry",
      help_text = "Workforce jobs by SIC section",
      help_text_source = "Source: ONS - Labour market statistics, workforce jobs by industry",
      help_link = "https://data.trade.gov.uk/datasets/4609dc12-0dfa-4734-8ecb-6c50b59d163d",
      help_link_text = "ONS Labour Market Overview",
      table_content  = reactableOutput(ns("wf_table"),  height = "400px"),
      visual_content = plotlyOutput(ns("wf_plot"),       height = "480px"),
      query = ns("sql_query"),

      controls = list(
        mod_quick_date_range_ui(
          id            = ns("wf_dates"),
          label_quick   = "Date range",
          label_picker  = "Time period",
          custom_picker = "slider",
          presets       = c("custom", "ytd", "past_year", "3y", "5y", "none")
        ),
        mod_filter_picker_ui(
          id = ns("sic_filter"),
          label = "Industry section filter",
          multiple = TRUE,
          actions_box = TRUE,
          live_search = TRUE,
          virtual_scroll = 10,
          selected_text_format = "count > 2"
        )
      ),

      accordion_controls = list(
        shinyWidgets::radioGroupButtons(
          inputId     = ns("colour_by"),
          label       = "Colour scheme",
          choices     = c("Industry section" = "sic_section", "Value (sequential)" = "value"),
          justified   = TRUE,
          size        = "sm",
          status      = "danger"
        ),
        shinyWidgets::radioGroupButtons(
          inputId      = ns("label_mode"),
          label        = "Block labels",
          choices      = c("Industry + value" = "both", "Industry only" = "label", "Value only" = "value"),
          justified    = TRUE,
          size         = "sm",
          status       = "danger"
        )
      )
    )
  )
}

## WORKFORCE JOBS SERVER ## -----
employment_workforce_industry_stats_card_server <- function(id, conn = APP_DB$pool) {
  moduleServer(id, function(input, output, session) {

    AGG_CODES <- c("A-T", "G-T")

    shinyWidgets::updateRadioGroupButtons(session, "colour_by",  selected = "sic_section")
    shinyWidgets::updateRadioGroupButtons(session, "label_mode", selected = "both")

    # Base cleaned lazy tbl — cached (no filter inputs needed for the base)
    cleaned_full_tbl <- reactive({
      get_workforce_jobs_tbl()
    }) %>% bindCache("workforce_industry")   # static key: schema/table never changes

    # Picker is fed only non-aggregate sections
    sic_picker_tbl <- reactive({
      cleaned_full_tbl() %>%
        dplyr::filter(!sic_section %in% !!AGG_CODES)
    })
    sic_pick <- mod_filter_picker_server(
      id       = "sic_filter",
      data_tbl = sic_picker_tbl,
      column   = "sic_section"
    )

    # Date range module
    dates <- mod_quick_date_range_server(
      id                 = "wf_dates",
      data_tbl           = cleaned_full_tbl,
      presets            = c("custom", "ytd", "past_year", "3y", "5y", "none"),
      default            = "5y",
      frequency          = "monthly",
      custom_picker      = "slider",
      preserve_selection = TRUE
    )

    # Date-filtered collected data (still includes aggregates so stat cards work)
    dat <- reactive({
      dr        <- dates$date_range()
      date_from <- if (!is.null(dr) && length(dr) == 2) as.Date(dr[[1]]) else NULL
      date_to   <- if (!is.null(dr) && length(dr) == 2) as.Date(dr[[2]]) else NULL

      t <- cleaned_full_tbl() %>%
        apply_filters_general(
          date_col  = "time_period",
          date_from = date_from,
          date_to   = date_to
        )

      list(
        data = t %>% dplyr::collect(),
        sql  = sql_render_pool_safe(t)
      )
    })

    # Snapshot: latest time_period within filtered range (drives stat cards)
    snapshot_df <- reactive({
      df <- dat()$data
      req(nrow(df) > 0)
      latest_period <- max(df$time_period, na.rm = TRUE)
      df %>%
        dplyr::filter(time_period == latest_period) %>%
        dplyr::filter(!is.na(value), value > 0)
    })

    # Non-aggregate sections at the latest period, with SIC picker applied
    industry_df <- reactive({
      df <- snapshot_df()
      sel <- sic_pick$selected()
      df <- df %>% dplyr::filter(!sic_section %in% !!AGG_CODES)
      if (length(sel) > 0) df <- df %>% dplyr::filter(sic_section %in% !!sel)
      df %>% dplyr::arrange(dplyr::desc(value))
    })

    # ---- Outputs ----
    output$sql_query <- renderText({ dat()$sql })

    output$wf_table <- reactable::renderReactable({
      df <- industry_df(); req(nrow(df) > 0)
      reactable::reactable(
        df %>% dplyr::select(industry, sic_section, time_period, value) %>%
               dplyr::mutate(value = round(value, 1)),
        sortable   = TRUE,
        filterable = TRUE,
        resizable  = TRUE,
        pagination = TRUE,
        highlight  = TRUE,
        striped    = TRUE,
        columns    = list(
          value = reactable::colDef(name = "Jobs (000s)")
        )
      )
    })

    output$wf_plot <- plotly::renderPlotly({
      df <- industry_df(); req(nrow(df) > 0)
      dbt_build_treemap(
        df         = df,
        label_col  = "industry",
        title_text = "Workforce Jobs by Industry",
        snapshot_label = format(max(df$time_period, na.rm = TRUE), "%b %Y"),
        hover_unit_label = "Jobs (000s)",
        download_filename_prefix = "workforce_jobs",
        colour_by  = input$colour_by  %||% "sic_section",
        label_mode = input$label_mode %||% "both"
      )
    })
  })
}

## WORKFORCE JOBS DATA ## ------

# Workforce jobs table: ons.labour_market__workforce_jobs
# time_period like "Jun 24 (p)" — strip "(p)" suffix then parse as Mon YY.
get_workforce_jobs_tbl <- function() {
  base <- dplyr::tbl(APP_DB$pool,
                     dbplyr::in_schema("ons", "labour_market__workforce_jobs"))

  period_sql <- dbplyr::sql("
    to_date(
      initcap(btrim(regexp_replace(time_period::text, '\\\\s*\\\\(p\\\\)\\\\s*$', '', 'i'))),
      'Mon YY'
    )::date
  ")

  base %>%
    dplyr::mutate(time_period = !!period_sql) %>%
    dplyr::select(
      time_period,
      industry,
      sic_section,
      value
    )
}
