## TOTAL SERVICES (WORKFORCE) KPI UI ## -----
employment_workforce_services_kpi_card_ui <- function(id) {
  ns <- NS(id)
  tagList(
    uiOutput(ns("card"))
  )
}

## TOTAL SERVICES (WORKFORCE) KPI SERVER ## -----
employment_workforce_services_kpi_card_server <- function(id) {
  moduleServer(id, function(input, output, session) {

    output$card <- build_kpi_card(
      id              = session$ns("workforce_services"),
      title           = "Total Services (SIC G-T) (000s)",
      schema          = "ons",
      table           = "labour_market__workforce_jobs",
      filter_col      = "sic_section",
      filter_value    = "G-T",
      parse_mode      = "MMM YY (p)",
      good_if_increase = TRUE,
      format_headline = govuk_format_number,
      format_delta    = function(x) govuk_format_number_signed(x, digits = 0)
    )
  })
}
