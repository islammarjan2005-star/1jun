## TOTAL SERVICES (VACANCIES) KPI UI ## -----
vacancies_services_kpi_card_ui <- function(id) {
  ns <- NS(id)
  tagList(
    uiOutput(ns("card"))
  )
}

## TOTAL SERVICES (VACANCIES) KPI SERVER ## -----
vacancies_services_kpi_card_server <- function(id) {
  moduleServer(id, function(input, output, session) {

    output$card <- build_kpi_card(
      id              = session$ns("vacancies_services"),
      title           = "Total Services (SIC G-S) (000s)",
      schema          = "ons",
      table           = "labour_market__vacancies_industry",
      filter_col      = "sic_section",
      filter_value    = "G-S",
      parse_mode      = "MMM-MMM YYYY",
      good_if_increase = TRUE,
      format_headline = govuk_format_number,
      format_delta    = function(x) govuk_format_number_signed(x, digits = 0)
    )
  })
}
