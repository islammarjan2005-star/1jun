# ---- TREEMAP (single-snapshot, plotly) ----

dbt_build_treemap <- function(
  df,
  label_col,
  value_col       = "value",
  group_col       = "sic_section",
  colour_by       = c("sic_section", "value"),
  label_mode      = c("both", "label", "value"),
  title_text,
  snapshot_label,
  hover_unit_label,
  download_filename_prefix,
  categorical_palette = dbt_palettes$dbt$extended,
  sequential_palette  = c("#b0c9e1", "#4174a3", "#00285f"),
  font_family         = "GDS Transport, Arial, sans-serif"
) {
  colour_by  <- match.arg(colour_by)
  label_mode <- match.arg(label_mode)

  textinfo_map <- c(
    both  = "label+value+percent parent",
    label = "label",
    value = "value+percent parent"
  )
  textinfo_val <- textinfo_map[[label_mode]]

  group_vec <- df[[group_col]]
  value_vec <- df[[value_col]]

  if (colour_by == "sic_section") {
    levels_vec <- unique(group_vec)
    pal        <- rep(categorical_palette, length.out = length(levels_vec))
    colour_vec <- pal[match(group_vec, levels_vec)]
  } else {
    v_norm     <- (value_vec - min(value_vec)) /
                  (max(value_vec) - min(value_vec) + 1e-9)
    seq_pal    <- grDevices::colorRampPalette(sequential_palette)(100)
    colour_vec <- seq_pal[pmax(1L, ceiling(v_norm * 100))]
  }

  marker_cfg <- list(
    colors = colour_vec,
    line   = list(width = 1.5, color = "#ffffff")
  )

  # Rename to fixed names so plotly aesthetics reference them stably across
  # rlang/plotly versions .
  df_local <- df
  df_local$.tm_label <- df_local[[label_col]]
  df_local$.tm_value <- df_local[[value_col]]
  df_local$.tm_group <- df_local[[group_col]]

  hovertemplate <- paste0(
    "<b>%{label}</b><br>",
    "SIC section: ", df_local$.tm_group, "<br>",
    hover_unit_label, ": %{value:,.1f}<br>",
    "Share: %{percentParent:.1%}<extra></extra>"
  )

  plotly::plot_ly(
    data       = df_local,
    type       = "treemap",
    labels     = ~.tm_label,
    parents    = ~"",
    values     = ~.tm_value,
    textinfo   = textinfo_val,
    hovertemplate = hovertemplate,
    marker     = marker_cfg,
    textfont   = list(family = font_family, size = 11)
  ) %>%
    plotly::layout(
      title = list(
        text = paste0("<b>", title_text, "</b><br>",
                      "<sup>Snapshot: ", snapshot_label,
                      " — values in 000s</sup>"),
        font = list(family = font_family, size = 14, color = "#0b0c0c"),
        x = 0, xanchor = "left"
      ),
      margin    = list(t = 60, l = 0, r = 0, b = 0),
      paper_bgcolor = "#ffffff",
      font      = list(family = font_family)
    ) %>%
    plotly::config(
      displayModeBar = TRUE,
      modeBarButtonsToRemove = c("lasso2d", "select2d"),
      toImageButtonOptions  = list(
        format   = "svg",
        filename = paste0(download_filename_prefix, "_", snapshot_label)
      )
    )
}
